# zstub相关通信SDK
from zstub.zstub_impl import ZStubImpl
from zstub.constants.constants import *
from zstub.io.interfaces.subscription import Subscription
from zstub.constants.constants import *
from zstub.io.interfaces.zmsg import ZMsg
from zstub.io.interfaces.conf.conf import *

# 其他业务相关依赖
import time
import threading
from datetime import datetime
import logging
import argparse
import json

# 初始化SDK，建议相关参数非必要不修改
logging.basicConfig(level=logging.INFO,
                    format='[%(levelname)s][%(asctime)s][%(name)s][%(filename)s,%(funcName)s,%(lineno)s][%(message)s]')
logger = logging.getLogger(__name__)
data_type_list = [MEC_T_TF, MEC_T_RSM, MEC_T_SPAT]      # 接入数据种类配置：RSM、TF和SPAT3种数据接入
output_dst = "app1"
config = '{"application_id":"app0","mec_service":"127.0.0.1","default_mqtt_broker":"127.0.0.1","default_mqtt_port":1883}'       # 运行环境数据来源配置
out = None
zstub = None
sub = None

# 接入数据后回调，用户请根据接入数据类型构建相应的逻辑代码，以实现算法实时接入数据
# 接入后即为json格式的数据
def sdk_msg_handler(msg_type, msg_body, origin):
    dt = datetime.fromtimestamp(datetime.now().timestamp())
    if msg_type == MEC_T_RSM:
        logger.info("Received participant data: {}".format(msg_body))
        rsm = json.loads(msg_body)
        for participant in rsm['participants']:
            pass
    elif msg_type == MEC_T_SPAT:
        logger.info("Received Signal Phase And Timing data: {}".format(msg_body))
        spat = json.loads(msg_body)
        for intersection in spat['intersections']:
            pass
    elif msg_type == MEC_T_TF:
        logger.info("Received Traffic Flow data: {}".format(msg_body))
        tf = json.loads(msg_body)
        for stat in tf['stats']:
            pass

# SDK错误回调，建议相关错误写入日志方便排查
def sdk_err_handler(err_code, err_msg):
    logger.error("handle err, err_code=%d, err_msg=%s", err_code, err_msg)

# 模拟算法：定时每1s发出一次MSG_SignalScheme信号优化方案
# 实际发出时机，由用户自行修改
def timed_output():
    while True:
        time.sleep(1)
        dt = datetime.fromtimestamp(datetime.now().timestamp())
        print(
            f'-----------------{dt.hour}:{dt.minute}:{dt.second}-----------------')
        # 构建符合消息结构定义的json字符串
        ss = {
            "scheme_id": 1,
            "node_id": {
                "region": 1,
                "id": 456
            },
            "time_span": {
                "month_filter": [
                    "SEP"
                ],
                "day_filter": [
                    6
                ],
                "weekday_filter": [
                    "WED"
                ],
                "from_time_point": {
                    "hh": 8,
                    "mm": 0,
                    "ss": 0
                },
                "to_time_point": {
                    "hh": 18,
                    "mm": 0,
                    "ss": 0
                }
            },
            "cycle": 100,
            "control_mode": "CYCLIC_FIXED",
            "min_cycle": 100,
            "max_cycle": 100,
            "base_signal_scheme_id": 1,
            "offset": 0,
            "phases": [
                {
                    "id": 1,
                    "order": 1,
                    "movements": [
                        "EastGoStraight",
                        "WestGoStraight",
                        "EastTurnRight",
                        "WestTurnRight",
                        "NorthPedestrainPass",
                        "SouthPedestrainPass"
                    ],
                    "green": 22,
                    "yellow": 3,
                    "allred": 5,
                    "min_green": 22,
                    "max_green": 22
                },
                {
                    "id": 2,
                    "order": 2,
                    "movements": [
                        "EastTurnLeft",
                        "WestTurnLeft"
                    ],
                    "green": 17,
                    "yellow": 3,
                    "allred": 0,
                    "min_green": 17,
                    "max_green": 17
                },
                {
                    "id": 3,
                    "order": 3,
                    "movements": [
                        "SouthGoStraight",
                        "NorthGoStraight",
                        "SouthTurnRight",
                        "NorthTurnRight",
                        "EastPedestrainPass",
                        "WestPedestrainPass"
                    ],
                    "green": 22,
                    "yellow": 3,
                    "allred": 5,
                    "min_green": 22,
                    "max_green": 22
                },
                {
                    "id": 4,
                    "order": 4,
                    "movements": [
                        "NorthTurnLeft",
                        "SouthTurnLeft"
                    ],
                    "green": 17,
                    "yellow": 3,
                    "allred": 0,
                    "min_green": 17,
                    "max_green": 17
                }
            ],
            "msg_id": 1
        }
        test_ss = json.dumps(ss)
        # 构造SDK消息体对象zmsg，填入消息种类代号MEC_T_SS
        # 注意字符串消息需要encode成为bytes对象
        zmsg = ZMsg(MEC_T_SS, test_ss.encode(), K_CONTENT_TYPE_JSON)
        # 使用SDK输出
        out.send(zmsg)

# 初始化SDK相关变量和算法线程
def run(args):
    global out, zstub, sub
    zstub = ZStubImpl(config)
    sub = zstub.subscribe(data_type_list)
    sub.set_msg_handler(sdk_msg_handler)
    sub.set_err_handler(sdk_err_handler)
    out = zstub.out_connect(output_dst)
    output_thread = threading.Thread(target=timed_output)
    output_thread.daemon = True
    output_thread.start()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-t", "--test", help='Run test data', type=int, default=0)
    args = parser.parse_args()
    run(args)

