# autodeploy_template/__init__.py
# from <parent_folder>.<python_file> import (
#     <every_class>, 
#     <every_function>, 
#     <every_variable>,
# )